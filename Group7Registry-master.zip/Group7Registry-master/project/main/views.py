# Authors: CMSC 495 Group 7, Zack Waurin, Kevon White, Matthew Wood
# Filename: views.py
# Description: Defines the API view functions for the Django project


from rest_framework import status
from rest_framework.response import Response
from rest_framework.decorators import api_view
from rest_framework.parsers import JSONParser
from .serializers import AccountSerializer, GiftListSerializer, GiftSerializer
from .models import Account, Gift, GiftList
from django.http import HttpResponse


@api_view(['GET'])
def index(request):
    return Response({"message": "Welcome to the CMSC 495 Group 7 Project, a Gift Registry API. Please refer to the documentation for details."})


# Creates a new account in the database. POST method accepts a JSON object with one username property.
@api_view(['POST'])
def create_account(request):
    if request.method == 'POST':
        account_data = JSONParser().parse(request)
        username = account_data['username']
        print(account_data)
        try:
            account = Account.objects.get(username=username)
            return Response({'message': 'Username with that name already exists.'})

        except Account.DoesNotExist:
            serializer = AccountSerializer(data=account_data)

            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data, status=status.HTTP_201_CREATED)
            else:
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            

# Views an account in the database. GET method will return a JSON object with the account id, username, and list of friends.
@api_view(['GET'])
def view_account(request, username):
    try:
        account = Account.objects.get(username=username)
    except Account.DoesNotExist:
        return Response({'message': 'Username not found.'}, status=status.HTTP_404_NOT_FOUND)

    if request.method == 'GET':
        serializer = AccountSerializer(account)
        return Response(serializer.data, status=status.HTTP_200_OK)


# Updates an account in the database. PUT method accepts a JSON object with one username property, and returns a JSON object 
# with the account id, username, and list of friends.
@api_view(['PUT'])
def update_account(request, username):
    try:
        account = Account.objects.get(username=username)
    except Account.DoesNotExist:
        return Response({'message': 'Username not found.'}, status=status.HTTP_404_NOT_FOUND)

    if request.method == 'PUT':        
        serializer = AccountSerializer(account, data=request.data, partial=True)
        if(serializer.is_valid()):
            serializer.save()
            return Response(serializer.data, status=status.HTTP_200_OK)
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# Deletes an account in the database, the account name to be deleted will be passed through the URL in the
# username field
@api_view(['DELETE'])
def delete_account(request, username):
    try:
        account = Account.objects.get(username=username)
    except Account.DoesNotExist:
        return Response({'message': 'Username not found.'}, status=status.HTTP_404_NOT_FOUND)

    if request.method == 'DELETE':
        account.delete()
        return Response({"message": "User account deleted successfully."}, status=status.HTTP_200_OK)


# Adds a friend to the specified account
@api_view(['POST'])
def add_friend(request, username):
    try:
        account = Account.objects.get(username=username)
    except Account.DoesNotExist:
        return Response({'message': 'Username not found.'}, status=status.HTTP_404_NOT_FOUND)

    if request.method == 'POST':
        friend_id = request.data['friend_id']
        friend = Account.objects.get(id=friend_id)
        account.friends.add(friend)
        account.save()
        return Response({"message": "Friend added successfully."}, status=status.HTTP_200_OK)
        

# Deletes a friend from the specified account     
@api_view(['DELETE'])
def delete_friend(request, username):
    try:
        account = Account.objects.get(username=username)
    except Account.DoesNotExist:
        return Response({'message': 'Username not found.'}, status=status.HTTP_404_NOT_FOUND)

    if request.method == 'DELETE':
        friend_id = request.data['friend_id']
        friend = Account.objects.get(id=friend_id)
        account.friends.remove(friend)
        account.save()
        return Response({"message": "Friend removed successfully."}, status=status.HTTP_200_OK)
        

# Creates a giftlist for the account with the username specified in the URL request
@api_view(['POST'])
def create_giftlist(request, username):
    try:
        account = Account.objects.get(username=username)
    except Account.DoesNotExist:
        return Response({'message': 'Username not found.'}, status=status.HTTP_404_NOT_FOUND)

    if request.method == 'POST':
        gift = GiftList.objects.create(name=request.data['name'], owner=account)
        serializer = GiftListSerializer(gift)
        return Response(serializer.data, status=status.HTTP_201_CREATED)


# Views all giftlists of a specified an account and returns a list of JSON objects
@api_view(['GET'])
def giftlist_list(request, username):
    try:
        account = Account.objects.get(username=username)
    except Account.DoesNotExist:
        return Response({'message': 'Username not found.'}, status=status.HTTP_404_NOT_FOUND)

    if request.method == 'GET':
        giftlists = GiftList.objects.filter(owner=account.id)

        serializer = GiftListSerializer(giftlists, many=True)
        return Response(serializer.data)


# Views the giftlist specified by the giftlist id in the URL, and returns a list of JSON objects representing
# the gifts in that list.
@api_view(['GET'])
def giftlist_detail(request, username, gl_id):
    try:
        account = Account.objects.get(username=username)
    except Account.DoesNotExist:
        return Response({'message': 'Username not found.'}, status=status.HTTP_404_NOT_FOUND)

    try:
        giftlist = GiftList.objects.get(pk=gl_id)
    except GiftList.DoesNotExist:
        return Response({'message': 'Giftlist with that ID not found.'})

    if request.method == 'GET':
        serializer = GiftSerializer(giftlist.gifts.all(), many=True) 
        return Response(serializer.data, status=status.HTTP_200_OK)


# Updates the name of the specified giftlist. PUT method accepts a JSON object with one name property, and returns a JSON object 
# with the giftlist id, name, and list of gifts.
@api_view(['PUT'])
def update_giftlist(request, username, gl_id):
    try:
        account = Account.objects.get(username=username)
    except Account.DoesNotExist:
        return Response({'message': 'Username not found.'}, status=status.HTTP_404_NOT_FOUND)

    try:
        giftlist = GiftList.objects.get(pk=gl_id)
    except GiftList.DoesNotExist:
        return Response({'message': 'Giftlist with that ID not found.'}, status=status.HTTP_404_NOT_FOUND)

    if request.method == 'PUT':
        serializer = GiftListSerializer(giftlist, data=request.data, partial=True)
        if(serializer.is_valid()):
            serializer.save()
            return Response(serializer.data, status=status.HTTP_200_OK)
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)



# Deletes giftlist specified in the request URL.
@api_view(['DELETE'])
def giftlist_delete(request, username, gl_id):
    try:
        account = Account.objects.get(username=username)
    except Account.DoesNotExist:
        return Response({'message': 'Username not found.'}, status=status.HTTP_404_NOT_FOUND)

    try:
        giftlist = GiftList.objects.get(pk=gl_id)
    except GiftList.DoesNotExist:
        return Response({'message': 'Giftlist with that ID not found.'}, status=status.HTTP_404_NOT_FOUND)

    if request.method == 'DELETE':
        giftlist.delete()
        return Response({'message': 'Giftlist deleted successfully.'})


# Adds a gift to the specified giftlist and returns a JSON object of the gift
@api_view(['POST'])
def add_gift(request, username, gl_id):
    try:
        account = Account.objects.get(username=username)
    except Account.DoesNotExist:
        return Response({'message': 'Username not found.'}, status=status.HTTP_404_NOT_FOUND)

    try:
        gl = GiftList.objects.get(id=gl_id)
    except GiftList.DoesNotExist:
        return Response({'message': 'Giftlist with that ID not found.'}, status=status.HTTP_404_NOT_FOUND)

    if request.method == 'POST':
        gift = Gift.objects.create(
            name=request.data['name'],
            description=request.data['description'],
            link=request.data['link'],
            )
        gl.gifts.add(gift)
        gl.save()
        serializer = GiftSerializer(gift)
        return Response(serializer.data, status=status.HTTP_201_CREATED)


# Updates a gift in the database. PUT method accepts a JSON object with the properties on the gift object
# to be updated
@api_view(['PUT'])
def update_gift(request, username, gift_id):
    try:
        account = Account.objects.get(username=username)
    except Account.DoesNotExist:
        return Response({'message': 'Username not found.'}, status=status.HTTP_404_NOT_FOUND)

    if request.method == 'PUT':
        gift = Gift.objects.get(id=gift_id)
        serializer = GiftSerializer(gift,data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_200_OK)
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# Deletes gift object from the database based on gift id specified in the URL
@api_view(['DELETE'])
def delete_gift(request, username, gift_id):
    try:
        account = Account.objects.get(username=username)
    except Account.DoesNotExist:
        return Response({'message': 'Username not found.'}, status=status.HTTP_404_NOT_FOUND)

    if request.method == 'DELETE':
        gift = Gift.objects.get(id=gift_id)
        gift.delete()
        return Response({"message": "Gift deleted successfully."}, status=status.HTTP_200_OK)



