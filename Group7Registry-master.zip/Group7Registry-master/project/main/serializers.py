from rest_framework import serializers
from .models import Account, Gift, GiftList


class AccountSerializer(serializers.ModelSerializer):
    friends = serializers.PrimaryKeyRelatedField(many=True, queryset=Account.objects.all(),required=False)
    class Meta:
        model = Account
        fields = ['id', 'username','friends']



class GiftSerializer(serializers.ModelSerializer):
    
    class Meta:
        model = Gift
        fields = ['id', 'name', 'link', 'description', 'is_claimed']



class GiftListSerializer(serializers.ModelSerializer):
    gifts = GiftSerializer(many=True, required=False)

    class Meta:
        model = GiftList
        fields = ['id', 'name', 'owner', 'gifts']

    # def create(self, validated_data):
    #     gifts_validated_data = validated_data.pop('gifts')
    #     giftlist = GiftList.objects.create(**validated_data)

    #     for gift in gifts_validated_data:
    #         Gift.objects.create(giftlist=giftlist, **gift)

    #     return giftlist

    # def update(self, instance, validated_data):
    #     gifts_validated_data = validated_data.pop('gifts')
    #     gifts = (instance.gifts).all()
    #     gifts = list(gifts)
    #     instance.name = validated_data.get('name', instance.name)
    #     instance.owner = validated_data.get('owner', instance.owner)
    #     instance.save()

    #     for gift in gifts:
    #         gift = gifts.pop(0)
    #         gift.name = gifts_validated_data.get('name', gift.name)
    #         gift.link = gifts_validated_data.get('link', gift.link)
    #         gift.description = gifts_validated_data.get('description', gift.description)
    #         gift.is_claimed = gifts_validated_data.get('is_claimed', gift.is_claimed)
    #         gift.giftlist = gifts_validated_data.get('giftlist', gift.giftlist)
    #         gift.save()

    #     return instance
