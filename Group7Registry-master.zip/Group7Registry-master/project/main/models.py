from django.db import models
from django.contrib.auth.models import User
from django.utils.translation import ugettext_lazy as _


class Account(models.Model):
    username = models.CharField(max_length=50,unique=True, blank=False)
    friends = models.ManyToManyField("self")


class GiftList(models.Model):
    owner = models.ForeignKey(Account, on_delete=models.CASCADE)
    name = models.CharField(max_length=50, blank=False)
    gifts = models.ManyToManyField("main.Gift", verbose_name=_("gifts"))


class Gift(models.Model):
    name = models.CharField(max_length=100, blank=False)
    link = models.URLField(max_length=255, blank=False)
    description = models.TextField()
    is_claimed = models.BooleanField(default=False,null=True, blank=False)
