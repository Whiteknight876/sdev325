# Authors: CMSC 495 Group 7, Zack Waurin, Kevon White, Matthew Wood
# Filename: urls.py
# Description: Defines the URL paths for the Django project

from django.urls import path
from . import views


urlpatterns = [
    path('', views.index, name="index"),
    path('create_account/', views.create_account, name="create_account"),
    path('<str:username>/', views.view_account, name="view_account"),
    path('<str:username>/update_account/', views.update_account, name="view_account"),
    path('<str:username>/delete_account/', views.delete_account, name="delete_account"),
    path('<str:username>/add_friend/', views.add_friend, name="add_friend"),
    path('<str:username>/delete_friend/', views.delete_friend, name="delete_friend"),
    path('<str:username>/create_giftlist/', views.create_giftlist, name="create_giftlist"),
    path('<str:username>/giftlists/', views.giftlist_list, name="giftlist_list"),
    path('<str:username>/giftlists/<int:gl_id>/', views.giftlist_detail, name="giftlist_detail"),
    path('<str:username>/giftlists/<int:gl_id>/add_gift/', views.add_gift, name="add_gift"),
    path('<str:username>/giftlists/<int:gift_id>/update_gift/', views.update_gift, name="update_gift"),
    path('<str:username>/giftlists/<int:gift_id>/delete_gift/', views.delete_gift, name="delete_gift"),
    path('<str:username>/giftlists/<int:gl_id>/update_giftlist/', views.update_giftlist, name="giftlist_detail"),
    path('<str:username>/giftlists/<int:gl_id>/delete_giftlist/', views.giftlist_delete, name="giftlist_delete"), 
]
